<?php
echo "Hello World (php)\n"; 
?>
